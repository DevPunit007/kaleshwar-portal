<?php

return [
    'language' => 'Language',
    'english' => 'English',
    'german' => 'German',
    'czech' => 'Czech',
    'finnish' => 'Finnish',
    'french' => 'French',
    'japanese' => 'Japanese',
    'group' => 'Group',
    'teacher' => 'Teacher|Teachers',
    'address' => 'Address',
    'contact' => 'Contact',
    'title' => 'Title',
    'location' => 'Location',
    'category' => 'Category',
    'start' => 'Start',
    'end' => 'End',

    'no_data_found' => 'No data found in database'
];
