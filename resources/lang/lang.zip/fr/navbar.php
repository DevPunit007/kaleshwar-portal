<?php

return [
    'user-account' => 'User Account',
    'bookings' => 'Bookings',
    'settings' => 'Settings',
    'logout' => 'Logout'
];
