<?php

return [
    'header' => 'Warm welcome to the Ashram portal',
    'topics_teachings' => 'Topics and Teachings'
];
