<?php

return [
    'users' => 'User',
    'teacher' => 'Teacher|Teachers',
    'groups' => 'Group',
    'locations' => 'Locations',
    'events' => 'Events',
    'bookings' => 'Bookings',
    'payments' => 'Payments',
    'app' => 'App',
    'media_center' => 'Media Center',
    'timeline' => 'Timeline',
    'reports' => 'Reports',
    'payments' => 'Payments',
    'translations' => 'Translations',

];
