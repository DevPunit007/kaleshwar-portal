<?php

return [
    // list
    'button-details' => 'Details and Contact',
    'button-events' => 'List of events',
    'filter-search' => 'Filter and Search bar',
    'search' => 'Search',
    'choose-topic' => 'Choose Topic',
    'general_topics' => 'General topics',
    'certified_teachings' => 'Certified teachings',

    //details
    'subtitle-topics' => 'List of general topics',
    'subtitle-acticities' => 'List of regular activities',
    'subtitle-teachings' => 'List of certified teachings',
    'subtitle-events' => 'List of Events',
    'message-events' => 'In the future you will see here the list of events which are offered by',


];
